CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.5.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(80) DEFAULT NULL,
  `password` varchar(120) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `resume` varchar(100) DEFAULT NULL,
  `role` varchar(2) DEFAULT '0',
  `CID` int(255) DEFAULT NULL,
  `activation_key` varchar(100) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `registered` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `resume2` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `coverLetter` varchar(1500) DEFAULT NULL,
  `resumeUploaded` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,'ab39e471c2e2f0b01974efc207b57a0548320930fee46',NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,NULL,NULL,NULL,NULL,NULL,'0',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'andrew123','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d9','abc123@hotmail.com','19/03/2013',NULL,'0',0,'M',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'andrew','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abc123@hotmail.com','13/03/2013',NULL,'2',14,'M','2013-06-12 13:29:28',NULL,NULL,NULL,NULL,NULL,'2013-06-12 10:49:50'),(6,'andrewy','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abc123@hotmail.com','27/03/2013',NULL,'0',0,'M',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'sujadmin','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abcasfd@gmail.com','SUJ',NULL,'1',NULL,NULL,'2013-06-11 12:40:17',NULL,NULL,NULL,NULL,NULL,'2013-06-11 12:40:17'),(8,'sujtest','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abcasfd@gmail.com','suj',NULL,'2',48,NULL,'2013-06-11 12:38:42',NULL,NULL,'8-2381_2011512015344271374.jpg','',NULL,'2013-06-11 12:39:02'),(9,'testing','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abcasfd@gmail.com','andrew',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'testing1','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abcasfd@gmail.com','andrew',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'andrew1','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','abcasfd@gmail.com','andrew',NULL,'0',NULL,NULL,NULL,'2013-05-22 09:25:41',NULL,NULL,NULL,NULL,NULL),(12,'andrew','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','asf2as@asdfas.saf','asfas',NULL,'0',NULL,NULL,NULL,'2013-05-23 08:01:14',NULL,NULL,NULL,NULL,NULL),(13,'sujtest1','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','asd@asf.asdf','asfsa','13-print.pdf','2',52,NULL,'2013-06-11 12:35:52','2013-05-27 09:30:50','13-print.pdf','13-6a0133f3a4072c970b0153910e98b6970b-800wi.jpg','asdfadasdfasfasfasd<br />\r\na<br />\r\na<br />\r\naaasfaasaAA','2013-05-31 03:04:03','2013-06-11 12:35:52'),(14,'sujtest2','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','asd@asf.asdf','aasfs','14-finalResume.docx','0',51,NULL,'2013-06-11 12:25:08','2013-05-28 05:46:12','14-bill1.docx',NULL,NULL,NULL,'2013-06-11 12:25:08'),(15,'abc123','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','aasdf@asdf.asfa','asf',NULL,'0',NULL,NULL,NULL,'2013-06-11 02:42:00',NULL,NULL,NULL,NULL,NULL),(16,'abc123','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','aasdf@asdf.asfa','asf',NULL,'0',NULL,NULL,NULL,'2013-06-11 02:43:13',NULL,NULL,NULL,NULL,NULL),(17,'abc123','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','aasdf@asdf.asfa','asf',NULL,'0',NULL,NULL,NULL,'2013-06-11 02:43:38',NULL,NULL,NULL,NULL,NULL),(18,'asfasasfsa','7be60a3eee4f4ced30e5f2ace52b3fd5af02270e9e1d929a912dcfcc47fd39a4b4a1ad10023f1bbea83ba948c6a22a769bb1','as@asd.asfsas','asfas',NULL,'0',NULL,NULL,NULL,'2013-06-11 02:44:23',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-06-13  8:50:25
