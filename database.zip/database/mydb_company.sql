
-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.5.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(45) DEFAULT NULL,
  `ID` varchar(45) DEFAULT NULL,
  `cemail` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `image` varchar(150) DEFAULT 'default.jpg',
  `contact` int(11) DEFAULT NULL,
  `job_count` int(11) DEFAULT '0',
  `status` varchar(45) DEFAULT NULL,
  `started` timestamp NULL DEFAULT NULL,
  `awards` varchar(45) DEFAULT NULL,
  `summary` varchar(100) DEFAULT NULL,
  `coverpicture` varchar(150) DEFAULT NULL,
  `mission` varchar(1500) DEFAULT NULL,
  `culture` varchar(1500) DEFAULT NULL,
  `benefits` varchar(1500) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `twitter` varchar(150) DEFAULT NULL,
  `facebook` varchar(150) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `unique_views` int(11) DEFAULT '0',
  `views` int(11) DEFAULT '0',
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (14,'Facebook Pte Ltd','5','ajyoung1@e.ntu.edu.sg','Changi Village road','14-6a0133f3a4072c970b0153910e98b6970b-800wi.jpg',91234567,0,'1',NULL,NULL,NULL,'14-OurSong.mp3','Artsicle is a company with a mission - to make art happen. We intend to break down the barriers that are restricting innovation and growth in the art market. We intend to support today\'s artists as they grow their careers. We intend to open the doors for everyone to become a collector of original, contemporary art. ','Here at Artsicle, our backgrounds are as diverse as the neighborhood we call home, but we\'re all passionate about building a truly transformative product. On a team this small, we can\'t afford to pigeonhole ourselves to one role, and be honest, we like it that way.','We offer competitive salaries, stock options, and full benefits.  Oh, and some fun perks:<br />\r\n<br />\r\n    Artsicle stipend = original art in your home<br />\r\n    Shiny Apple equipment<br />\r\n    Team adventures & outings<br />\r\n    Office snacks<br />\r\n    ZipCar membership, and more...','Singapore',NULL,NULL,NULL,NULL,'2013-06-12 07:43:49',0,0),(48,'Google International','8','abc@cbd.efg','Blk 255 <br />\r\nAnson road<br />\r\nSingapore 1','48-a.com_logo_RGB.jpg',91234567,0,'1',NULL,NULL,NULL,'48-test1.jpg','Barrel is a focused and nimble team of designers, developers, and strategists. Our passion for design, technology, and content fuels our desire to create inventive solutions. We love fresh ideas and obsess over execution, consistently delivering strong results. We\'ve worked with startups and established organizations across various industries, gaining a broad perspective on how digital strategy can impact a client\'s goals.','At Barrel, we follow a core belief: care about what you do and find ways to keep on getting better. If you think the same way, you\'re looking in the right place.','ELEVEN REASONS WHY YOU\'LL LOVE WORKING AT BARREL<br />\r\nTeam Chemistry -- We believe that we\'re only as strong as the bonds of our team members. We help each other, teach each other, and always have each others\' backs.<br />\r\nChallenging Work -- Whether it\'s learning new technologies or solving difficult design problems, we constantly seek new challenges that will keep us fully engaged.<br />\r\nFood & Drink -- We provide lunch five times a week and we\'re always stocked with snacks, fresh coffee, loose leaf tea, draught beers, and a liquor cabinet for serious cocktail enthusiasts.<br />\r\nProfessional Development -- We\'re all about learning and growing. We\'re happy to foot the bill for conferences, workshops, and events that\'ll help you become better at what you do.<br />\r\nHealth, Dental, and Vision Benefits -- We\'re serious about your health. We cover 50% of your health insurance premiums and 100% of vision and dental.<br />\r\nTools -- We\'ll make sure that you have a comfortable Aeron chair, a fast Mac, the latest software, and whatever else you need (fonts, plug-ins, Wacom tablet, etc.) to be productive. If you think there\'s a tool you can build to help your job, we\'ll give you time to do that as well!<br />\r\nTime Off -- We offer 8 days of vacation right off the bat, and you gain an extra vacation day every year you\'re with us. We also offer flexible time-off arrangements if you need to go away for an extended period of time or work-at-home arrangements if you feel very product','Singapore',NULL,NULL,NULL,NULL,NULL,0,0),(52,'abc','13','asdfas@asdf.asdfas','','-add2cart.gif',NULL,0,'0',NULL,NULL,NULL,NULL,'asfsa',NULL,NULL,NULL,NULL,NULL,NULL,'2013-06-11 06:31:15','2013-06-11 06:31:15',0,0);
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-06-13  8:50:22
